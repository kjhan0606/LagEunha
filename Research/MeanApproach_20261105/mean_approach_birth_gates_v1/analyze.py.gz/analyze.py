"""Independent finite-pressure Noh and rarefaction errors at actual saved times."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

r=Path(__file__).resolve().parent
b=r.parent
sys.dont_write_bytecode=True
athena=b/'shu_independent_athena_v1/athena_source/tst/regression'
sys.path.insert(0,str(athena))
from scripts.utils.RiemannSolver.riemann import RiemannSol,StateVector,riemann_problem
from scripts.utils.EquationOfState.eos import Ideal
reports={}
for case in ['noh','doublefan']:
    path=r/'gates'/('D1_'+case+'_N200')
    result=json.loads((path/'result.json').read_text())
    t=result['time']
    d=np.loadtxt(path/'final.dat')
    if case=='noh':
        sol=riemann_problem(dict(dl=1,ul=1,pl=1e-6,dr=1,ur=-1,pr=1e-6),5/3)
        x0=0
    else:
        eos=Ideal(1.4)
        sol=RiemannSol(StateVector(rho=1,u=-2,p=.4,eos=eos),StateVector(rho=1,u=2,p=.4,eos=eos),eos)
        sol._pl=1e-8*min(sol.left.p,sol.right.p)
        sol.gen_sol()
        x0=.5
    cuts=sorted(set(x0+t*float(z) for w in sol.waves for z in w['speed']))
    norms=[]
    for order in [16,32]:
        node,weight=np.polynomial.legendre.leggauss(order)
        L1=np.zeros(3)
        volume=0
        for row in d:
            center=row[1]+row[16]
            l,h=max(center-.5*row[10],0),min(center+.5*row[10],1)
            if h<=l:continue
            volume+=h-l
            points=[l]+[x for x in cuts if l<x<h]+[h]
            for a,z in zip(points[:-1],points[1:]):
                xx=.5*(a+z)+.5*(z-a)*node
                ref=[sol.get_state((x-x0)/t) for x in xx]
                fields=np.array([[q.rho,q.p,q.u] for q in ref])
                L1+=.5*(z-a)*(weight[:,None]*abs(fields-row[[11,12,13]])).sum(axis=0)
        assert abs(volume-1)<1e-12
        norms.append(L1)
    centers=d[:,1]+d[:,16]
    inside=d[(centers>=0)&(centers<=1)]
    delta=np.diff(inside[:,13])
    bad=np.flatnonzero(delta<0)
    adjacent=np.unique(np.concatenate([bad,bad+1]))
    reports[case]={'scope':'Actual saved time, never substituted for the original endpoint',
                   'actual_time':t,'original_target':result['target'],'endpoint_reached':not result['failed'],
                   'density_pressure_velocity_L1':norms[1].tolist(),
                   'absolute_quadrature_difference_16_to32':abs(norms[1]-norms[0]).tolist(),
                   'exact_middle_rho_P_u':[sol.rmid.rho,sol.rmid.p,sol.rmid.u],
                   'physical_cell_maximum_density':float(max(inside[:,11])),
                   'physical_cell_maximum_pressure':float(max(inside[:,12])),
                   'wall_cell_density_pressure_velocity':d[0,[11,12,13]].tolist() if case=='noh' else None,
                   'total_downward_mean_velocity_variation':float(np.maximum(0,-delta).sum()) if case=='doublefan' else None,
                   'volume_of_cells_adjacent_to_nonmonotone_pairs':float(inside[adjacent,10].sum()) if case=='doublefan' else None,
                   'final_checkpoint_sha256':hashlib.sha256((path/'final.fv').read_bytes()).hexdigest()}
assessment={'scope':'Failed physical9 candidate; Noh completion does not qualify the whole method',
            'cases':reports,'candidate_accepted':False,'larger_suite_released':False,
            'rejection_reasons':['doublefan misses original endpoint','cold64 pressure error exceeds1%'],
            'reference_source':str(athena/'scripts/utils/RiemannSolver/riemann.py'),
            'near_vacuum_reference_bracket':'Doublefan root bracket extended below default lower pressure; exact Euler problem and evolved method unchanged'}
(r/'physical_assessment.json').write_text(json.dumps(assessment,indent=2,allow_nan=False)+'\n')
print(json.dumps(assessment,indent=2))
