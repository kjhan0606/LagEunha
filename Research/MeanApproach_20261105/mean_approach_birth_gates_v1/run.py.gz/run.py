"""Physical9 finite birth gates: Noh, double rarefaction, cold shear64."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import numpy as np

r=Path(__file__).resolve().parent
b=r.parent
stage=b/'mean_approach_stage_v1'
assert json.loads((stage/'assessment.json').read_text())['pass']
for name in ['run_fv_native_suite.py','run_kep_filter_gates.py']:
    shutil.copy2(stage/'frozen_source/Exam/HydroCore'/name,r/name)
sys.path.insert(0,str(r))
from run_fv_native_suite import execute,save
reject=r/'physical8_restart_rejection';reject.mkdir(exist_ok=False)
cmd=[str(stage/'native'),'1','200','noh','.6','1',str(b/'compensated_original_nine_v1/gates/D1_noh_N200/final.fv')]
env=dict(os.environ,TMPDIR=str(r),OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE')
with (reject/'stdout.log').open('x') as out,(reject/'stderr.log').open('x') as err:
    code=subprocess.run(cmd,cwd=reject,stdout=out,stderr=err,env=env,timeout=60).returncode
assert code==3 and not (reject/'initial.fv').exists()
cases=[('D1_noh_N200',1,200,'noh',.6),('D1_doublefan_N200',1,200,'doublefan',.15),('D2_cold_N64',2,64,'cold',.25)]
cpu_sets=[[0],[8],list(range(16,24))]
save(r/'registration.json',{'scope':'Finite common physical9 birth gates; no physical8 restart or prior pass reuse',
                          'physical_version':9,'binary_sha256':hashlib.sha256((stage/'native').read_bytes()).hexdigest(),
                          'cases':cases,'CPU_sets':cpu_sets,'OMP_threads':[1,1,8],
                          'physical8_restart_rejected':True,'cold_pressure_relative_L1_limit':.01,
                          'PCG_cap':64,'true_tolerance':1e-12,'coefficients':[1,2],'guard_multiplier':1,
                          'stop':'No larger suite if any of the three gates fails; no coefficient/CFL/cap/mu changes.'})
gates=r/'gates';gates.mkdir(exist_ok=False)
def run(item):
    index,case=item
    record=execute(gates,stage/'native',case,cpu_sets[index],{'OMP_NUM_THREADS':str(len(cpu_sets[index])),'GFS_TEST_GUARD_MULTIPLIER':'1'})
    p=gates/case[0]
    record['kinetic_ledger']=json.loads((p/'kinetic_ledger.json').read_text())
    assert record['kinetic_ledger']['checkpoint_version']==9
    if case[3]=='cold':
        final=np.loadtxt(p/'final.dat');record['cold_pressure_relative_L1']=float(np.sum(final[:,10]*abs(final[:,12]/1e-6-1)))
        record['cold_pressure_gate_pass']=record['endpoint_pass'] and record['cold_pressure_relative_L1']<=.01
    save(p/'gate_assessment.json',record)
    print(json.dumps(record),flush=True)
    return record
with ThreadPoolExecutor(max_workers=3) as pool:
    records=list(pool.map(run,enumerate(cases)))
complete=all(q['endpoint_pass'] and q.get('cold_pressure_gate_pass',True) for q in records)
save(r/'assessment.json',{'scope':'Endpoint/numerical/cold pressure gates; exact Noh/rarefaction physics evaluated separately',
                        'cases':records,'all_three_primary_gates_pass':complete})
if not complete:raise SystemExit(1)
