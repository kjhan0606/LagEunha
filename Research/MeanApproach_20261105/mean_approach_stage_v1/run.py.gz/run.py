"""Physical9 mean-approach stress, one fixed finite gate bundle."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

r=Path(__file__).resolve().parent
b=r.parent
repo=b.parent/'Git_publish_native20pi_contact_20261104_v1'
s=r/'frozen_source'
s.mkdir(exist_ok=False)
names=list(json.loads((b/'compensated_solution_stage_v2/manifest.json').read_text())['source_sha256'])
names+=['Exam/HydroCore/kep_mean_stress_audit.c']
for name in names:
    out=s/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,out)
base=['mpiicx','-O2','-qopenmp','-std=gnu11','-fp-model=precise','-ffp-contract=off','-DXYZDBL','-DGOTPM','-Wall','-Wextra']
common=['-DGFS_NATIVE_KEP','-DGFS_NATIVE_KEP_FILTER','-DGFS_NATIVE_GLOBAL_VELOCITY',
        '-DGFS_NATIVE_WALL_VELOCITY','-DGFS_NATIVE_SCALAR_VELOCITY','-DGFS_NATIVE_CENTROID_STRAIN',
        '-DGFS_NATIVE_IC0','-DGFS_NATIVE_COMPENSATED_SOLUTION']
new=['-DGFS_NATIVE_MEAN_APPROACH_STRESS']
diag=['-DGFS_KEP_STRESS_DIAGNOSTICS']
geom=[str(s/p) for p in ['Exam/gfs_fv_geometry.c','Exam/gfs_fv_point.c','Voro/voro.c']]
commands={}
for name,flag in [('old_probe',[]),('mean_probe',new)]:
    commands[name]=base+common+flag+diag+[str(s/'Exam/HydroCore/kep_mean_stress_audit.c')]+geom+['-lm','-o',str(r/name)]
commands['native']=base+common+new+[str(s/'Exam/gfs_fv_native.c'),str(s/'Exam/HydroCore/fv_native_evolution.c')]+geom+['-lm','-o',str(r/'native')]
for name,file in [('wall','kep_wall_field_audit.c'),('frame','kep_velocity_frame_audit.c'),('stress','kep_stress_switch_audit.c')]:
    commands[name+'_audit']=base+common+new+diag+[str(s/'Exam/HydroCore'/file)]+geom+['-lm','-o',str(r/(name+'_audit'))]
env=dict(os.environ,TMPDIR=str(r),OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',PYTHONDONTWRITEBYTECODE='1')
def build(item):
    name,cmd=item;(r/(name+'_command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
    with (r/(name+'_build.log')).open('x') as out:
        start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env,timeout=120)
    return name,{'exit_code':p.returncode,'seconds':time.monotonic()-start}
with ThreadPoolExecutor(max_workers=3) as pool:
    builds=dict(pool.map(build,commands.items()))
(r/'builds.json').write_text(json.dumps(builds,indent=2)+'\n');print('builds',builds,flush=True)
assert all(x['exit_code']==0 for x in builds.values())
(r/'manifest.json').write_text(json.dumps({'source_sha256':{str(f.relative_to(s)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(s.rglob('*')) if f.is_file()},'binary_sha256':{name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in commands}},indent=2)+'\n')
counts={}
for name in ['wall','frame','stress']:
    command=[str(r/(name+'_audit'))]+([] if name=='frame' else ['fixtures'])
    with (r/(name+'_stdout.jsonl')).open('x') as out,(r/(name+'_stderr.log')).open('x') as err:
        p=subprocess.run(command,stdout=out,stderr=err,env=env,timeout=60)
    assert p.returncode==0,name
    records=[json.loads(x) for x in (r/(name+'_stdout.jsonl')).read_text().splitlines() if x.strip()]
    assert all(x['pass'] for x in records);counts[name]=len(records)
    print(name,len(records),'pass',flush=True)
paths=[b/'compensated_original_nine_v1/gates'/('D1_'+case+'_N200')/'final.fv' for case in ['noh','doublefan']]
reports={}
for name in ['old_probe','mean_probe']:
    cmd=[str(r/name)]+list(map(str,paths))
    with (r/(name+'_stdout.jsonl')).open('x') as out,(r/(name+'_stderr.log')).open('x') as err:
        p=subprocess.run(cmd,stdout=out,stderr=err,env=env,timeout=60)
    assert p.returncode==0,name
    reports[name]=[json.loads(x) for x in (r/(name+'_stdout.jsonl')).read_text().splitlines() if x.strip()]
    assert all(x['pass'] for x in reports[name])
assert reports['old_probe'][0]['Pi']==0 and reports['mean_probe'][0]['Pi']>0
assert reports['old_probe'][1]['Pi']==reports['mean_probe'][1]['Pi']
assert sum(counts.values())==52
assessment={'scope':'Physical9 frozen common gates only, no evolved validation or restart of physical8',
            'physical_version':9,'same_mean_delta_raw_chi_centroid_length_coefficients':True,
            'only_physical_change':'Remove reconstructed compression gate; use approaching cell means',
            'fixture_counts':counts,'saved_controls_and_affine_scaling':reports,'pass':True,
            'next_conditional_birth_runs':[['noh',200,.6],['doublefan',200,.15],['cold',64,.25]],
            'cold_pressure_relative_L1_limit':.01,'no_coefficient_CFL_cap_mu_scan':True}
(r/'assessment.json').write_text(json.dumps(assessment,indent=2,allow_nan=False)+'\n')
print(json.dumps(assessment,indent=2),flush=True)
