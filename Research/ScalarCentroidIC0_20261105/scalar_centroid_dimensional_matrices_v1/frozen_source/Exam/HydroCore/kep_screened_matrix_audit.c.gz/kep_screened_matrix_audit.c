/* Read-only dimensional native RHS/matrix snapshot. Historical states are
 * operator inputs only and are never converted into new trajectories. */
#define main archived_native_main
#include "fv_native_evolution.c"
#undef main
#include "../gfs_fv_native.c"
int main(int argc,char **argv){
    if(argc!=3)return 2;FILE *in=fopen(argv[1],"rb");FvCheckpoint h;
    if(!in||fread(&h,sizeof(h),1,in)!=1||h.magic!=magic||h.cell_bytes!=sizeof(GfsFvCell)||h.count<2||h.count>1000000||h.dim<1||h.dim>3||(h.version&~diagnostic_trial_flag)<1||(h.version&~diagnostic_trial_flag)>8)return 2;
    GfsFvMesh m={0};m.dim=h.dim;m.n=h.count;m.gamma=h.gamma;memcpy(m.bc,h.bc,sizeof(m.bc));memcpy(m.lo,h.lo,sizeof(m.lo));memcpy(m.L,h.L,sizeof(m.L));
    m.cell=calloc(m.n,sizeof(*m.cell));if(!m.cell||fread(m.cell,sizeof(*m.cell),m.n,in)!=(size_t)m.n||fgetc(in)!=EOF||fclose(in))return 2;
    GfsFvCell *copy=malloc(m.n*sizeof(*copy));memcpy(copy,m.cell,m.n*sizeof(*copy));
    double mark=omp_get_wtime();if(gfs_fv_geometry(&m))return 3;double geometry_seconds=omp_get_wtime()-mark;
    GfsFvWorkspace *w=gfs_fv_workspace_create();GfsFvRate *rate=calloc(m.n,sizeof(*rate));GfsFvRhsStats stats;
    mark=omp_get_wtime();int code=gfs_fv_native_rhs(w,&m,rate,&stats);double rhs_seconds=omp_get_wtime()-mark;
    if(code==1||code==2)return 3; /* No screened system exists for a failed reconstruction/fan. */
    double *zero=calloc(m.n,sizeof(double)),*R0=calloc(m.n,sizeof(double));if(residual(w,&m,zero,R0,0))return 3;
    char path[4096];snprintf(path,sizeof(path),"%s_matrix.csv",argv[2]);FILE *out=fopen(path,"wx");if(!out)return 4;
    fprintf(out,"i,j,aij\n");for(int k=0;k<w->ne;k++){FvEdge *e=w->edge+k;if(e->j>=0)fprintf(out,"%d,%d,%.17g\n",e->i,e->j,e->jacobian);}
    if(fclose(out))return 4;
    snprintf(path,sizeof(path),"%s_rows.csv",argv[2]);out=fopen(path,"wx");if(!out)return 4;
    fprintf(out,"id,mu,diagonal,b,scale,z_candidate,volume,qx,qy,qz,qdotx,qdoty,qdotz\n");
    const double *candidate=code>=10?w->direction:w->z;double maximum=0;
    for(int i=0;i<m.n;i++){
        maximum=fmax(maximum,w->diagonal[i]/m.cell[i].mu);
        fprintf(out,"%d,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n",i,m.cell[i].mu,w->diagonal[i],-R0[i],w->scale[i],candidate[i],m.geometry[i].V,m.cell[i].q[0],m.cell[i].q[1],m.cell[i].q[2],w->velocity[i][0],w->velocity[i][1],w->velocity[i][2]);
    }if(fclose(out))return 4;
    if(residual(w,&m,candidate,w->trial,0))return 3;multiply(w,&m,candidate,w->Ap);
    double representation=0;for(int i=0;i<m.n;i++)representation=fmax(representation,fabs(w->trial[i]-w->Ap[i]-R0[i])/w->scale[i]);
    int unchanged=!memcmp(copy,m.cell,m.n*sizeof(*copy));
    double pair=fabs(stats.kinetic_rate-stats.kinetic_pressure_work+stats.kinetic_boundary_flux);
    printf("{\"scope\":\"readonly historical state under selected dimensional RHS; no trajectory\",\"source_checkpoint_version\":%llu,\"operator_checkpoint_version\":%llu,\"source_time\":%.17g,\"dim\":%d,\"cells\":%d,\"native_RHS_status\":%d,\"PCG_iterations\":%d,\"true_scaled_residual\":%.17g,\"native_flux_vs_matrix_representation_error\":%.17g,\"maximum_diagonal_over_mu\":%.17g,\"full_RHS_ledgers_available\":%s,\"kinetic_pair_defect\":%.17g,\"entropy_balance_defect\":%.17g,\"geometry_seconds\":%.17g,\"first_RHS_seconds_including_workspace_allocation\":%.17g,\"solve_seconds\":%.17g,\"conserved_states_and_birth_parameters_unchanged\":%s,\"accepted_evolution_steps\":0}\n",(unsigned long long)(h.version&~diagnostic_trial_flag),(unsigned long long)checkpoint_version,h.time,m.dim,m.n,code,stats.cg,norm(w,w->trial),representation,maximum,code?"false":"true",pair,stats.entropy_balance_defect,geometry_seconds,rhs_seconds,stats.solve_seconds,unchanged?"true":"false");
    free(zero);free(R0);free(copy);free(rate);gfs_fv_workspace_free(w);gfs_fv_geometry_free(&m);free(m.cell);return unchanged&&representation<1e-10?0:1;
}
