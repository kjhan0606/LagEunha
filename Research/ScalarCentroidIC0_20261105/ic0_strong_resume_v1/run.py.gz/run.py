from pathlib import Path
import hashlib,json,os,subprocess,time
import numpy as np
r=Path(__file__).parent;b=r.parent;build=b/'ic0_stage_v1';sources={name:b/'scalar_centroid_strong_launch_v1/gates'/('D1_'+name+'_N200')/'final.fv' for name in ['blast','collision']}
env=dict(os.environ,OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',TMPDIR=str(r))
# Compare A,b,scale and selected physical qdot at the EXACT restart entry.
checks={}
for case,state in sources.items():
 for mode in ['block','ic0']:
  prefix=r/(case+'_'+mode+'_entry')
  cmd=['taskset','-c','16',str(build/(mode+'_audit')),str(state),str(prefix)]
  with Path(str(prefix)+'.json').open('x') as out,Path(str(prefix)+'_stderr.log').open('x') as err:p=subprocess.run(cmd,stdout=out,stderr=err,env=env,timeout=60)
  assert p.returncode==0
 a=r/(case+'_block_entry');c=r/(case+'_ic0_entry')
 assert Path(str(a)+'_matrix.csv').read_bytes()==Path(str(c)+'_matrix.csv').read_bytes()
 aa=np.genfromtxt(str(a)+'_rows.csv',delimiter=',',names=True);cc=np.genfromtxt(str(c)+'_rows.csv',delimiter=',',names=True)
 for field in ['mu','diagonal','b','scale','volume','qx','qy','qz','qdotx','qdoty','qdotz']:assert np.array_equal(aa[field],cc[field]),(case,field)
 checks[case]={'path':str(state),'sha256':hashlib.sha256(state.read_bytes()).hexdigest(),'same_A_b_scale_and_physical_field':True,'entry_source_time':json.loads(Path(str(c)+'.json').read_text())['source_time']}
# The production loader must continue rejecting diagnostic trial files.
guard=r/'rejected_trial_loader';guard.mkdir(exist_ok=False)
cmd=[str(build/'native'),'1','200','blast','.038','1',str(b/'scalar_centroid_strong_launch_v1/gates/D1_blast_N200/failure_trial.fv')]
with (guard/'stdout.log').open('x') as out,(guard/'stderr.log').open('x') as err:p=subprocess.run(cmd,cwd=guard,stdout=out,stderr=err,env=env,timeout=60)
assert p.returncode==3 and not (guard/'initial.fv').exists()
(r/'entry_checks.json').write_text(json.dumps({'same_physics_checkpoint_version':8,'source_checks':checks,'diagnostic_trial_rejected':True,'guard_command':cmd,'guard_exit_code':p.returncode},indent=2)+'\n')
cmd=['python3',str(r/'run_kep_filter_gates.py'),str(r/'gates'),str(build/'native'),'--select','blast','collision','--core-version','8','--restart-blast',str(sources['blast']),'--restart-collision',str(sources['collision'])]
with (r/'stdout.log').open('x') as out,(r/'stderr.log').open('x') as err:
 start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err)
(r/'controller_process.json').write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
summary={}
for case,state in sources.items():
 directory=r/'gates'/('D1_'+case+'_N200');old=state.parent
 previous=json.loads((old/'result.json').read_text());current=json.loads((directory/'result.json').read_text())
 assert (directory/'initial.fv').read_bytes()==state.read_bytes()
 assert current['steps']==previous['steps']+current['new_steps']
 first=json.loads((old/'kinetic_ledger.json').read_text());last=json.loads((directory/'kinetic_ledger.json').read_text())
 summary[case]={'scope':'One physical-version8 trajectory with block-PCG first segment and IC0-PCG resume; not an all-IC0 benchmark','accepted_entry_time':previous['time'],'final_time':current['time'],'original_target':current['target'],'endpoint_pass':not current['failed'] and current['time']==current['target'],'entry_checkpoint_byte_identical':True,'steps_total':current['steps'],'steps_in_resume':current['new_steps'],'all_path_max_conservation_ledger':max(previous['maximum_ledger_error'],current['maximum_ledger_error']),'all_path_max_residual_corrected_mass_weight_invariant':max(previous['maximum_integrated_residual_invariant_error'],current['maximum_integrated_residual_invariant_error']),'whole_path_kinetic_RK_abs_defect':first['kinetic_RK_defect_abs_sum']+last['kinetic_RK_defect_abs_sum'],'whole_path_integrated_stress_heat':first['integrated_compression_thermal_production']+last['integrated_compression_thermal_production'],'whole_path_max_semidiscrete_entropy_balance_defect':max(first['maximum_semidiscrete_entropy_balance_defect'],last['maximum_semidiscrete_entropy_balance_defect']),'initial_continuum_kinetic_projection_difference':previous['initial_continuum_kinetic_projection_difference'],'last_result':current}
(r/'whole_physical_path.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
if p.returncode or not all(x['endpoint_pass'] for x in summary.values()):raise SystemExit(1)
