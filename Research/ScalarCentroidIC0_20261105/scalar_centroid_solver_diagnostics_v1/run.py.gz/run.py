import csv,hashlib,json,os,subprocess
from decimal import Decimal,localcontext
from pathlib import Path
import numpy as np
r=Path(__file__).parent;b=r.parent;s=r/'frozen_source'
cmd=json.loads((b/'scalar_centroid_stage_v1/frozen_11_command.json').read_text())
cmd=[x.replace(str(b/'scalar_centroid_stage_v1/frozen_source'),str(s)).replace('-DGFS_AUDIT_SOURCE_VERSION=5','-DGFS_AUDIT_SOURCE_VERSION=8') for x in cmd]
cmd.insert(1,'-DGFS_PCG_TRUE_HISTORY');cmd[-1]=str(r/'audit')
(r/'build_command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (r/'build.log').open('x') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0
env=dict(os.environ,OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',TMPDIR=str(r))
def run(name,args):
 command=[str(r/'audit')]+list(map(str,args))
 with (r/(name+'.json')).open('x') as out,(r/(name+'_stderr.log')).open('x') as err:p=subprocess.run(command,stdout=out,stderr=err,env=env,timeout=60)
 (r/(name+'_process.json')).write_text(json.dumps({'command':command,'exit_code':p.returncode},indent=2)+'\n')
 assert p.returncode==0
 return json.loads((r/(name+'.json')).read_text())
results={}
for case in ['blast','collision']:
 source=b/'scalar_centroid_strong_launch_v1/gates'/('D1_'+case+'_N200')
 state=source/'failure_trial.fv';prefix=r/case
 record=run(case,[state,prefix]);original=json.loads((source/'failure_stage.json').read_text())
 assert record['true_residual']==original['true_scaled_residual'] and record['actual_PCG_iterations']==64 and record['screened_solve_status']!=0
 cells=np.genfromtxt(str(prefix)+'_cells.csv',delimiter=',',names=True)
 edge=np.genfromtxt(str(prefix)+'_matrix.csv',delimiter=',',names=True)
 rhs=np.genfromtxt(str(prefix)+'_rhs.csv',delimiter=',',names=True)
 history=np.genfromtxt(str(prefix)+'_pcg_history.csv',delimiter=',',names=True)
 passing=history[history['true_scaled_flux_residual']<=1e-12]
 n=len(cells)
 with localcontext() as context:
  context.prec=60
  mu=[Decimal.from_float(float(x)) for x in cells['mu']]
  diagonal=mu.copy();off=[Decimal(0)]*(n-1)
  for e in edge:
   i,j=int(e['i']),int(e['j']);assert j==i+1
   a=Decimal.from_float(float(e['aij']));diagonal[i]+=a;diagonal[j]+=a;off[i]-=a
  D=[Decimal(0)]*n;L=[Decimal(0)]*n;y=[Decimal(0)]*n
  D[0]=diagonal[0];y[0]=Decimal.from_float(float(rhs['b'][0]))
  for i in range(1,n):
   L[i]=off[i-1]/D[i-1];D[i]=diagonal[i]-L[i]*off[i-1];assert D[i]>0
   y[i]=Decimal.from_float(float(rhs['b'][i]))-L[i]*y[i-1]
  x=[Decimal(0)]*n;x[-1]=y[-1]/D[-1]
  for i in range(n-2,-1,-1):x[i]=y[i]/D[i]-L[i+1]*x[i+1]
  text=[str(z) for z in x]
 reference=np.array([float(z) for z in x],dtype=np.float64);reference.tofile(r/(case+'_reference.vector.bin'))
 (r/(case+'_reference_decimal.json')).write_text(json.dumps({'scope':'Independent 60-digit tridiagonal LDL reference on frozen native A,b; not a PDE or production backend','decimal_precision':60,'x_decimal':text},indent=2)+'\n')
 run(case+'_reference',[state,r/(case+'_reference'),'--candidate-z',r/(case+'_reference.vector.bin')])
 check=json.loads((r/(case+'_reference_candidate_check.json')).read_text())
 result={'native_original_failure_reproduced_exactly':True,'native_solver':record,'minimum_true_flux_residual_in_64':float(min(history['true_scaled_flux_residual'])),'first_true_pass_iteration':int(passing[0]['iteration']) if len(passing) else None,'recursive_scaled_inf_at_first_true_pass':float(passing[0]['recursive_scaled_inf_residual']) if len(passing) else None,'relative_preconditioned_at_first_true_pass':float(passing[0]['recursive_preconditioned_relative_residual']) if len(passing) else None,'independent_LDL_60digit_rounded_double_reference':check}
 results[case]=result
(r/'assessment.json').write_text(json.dumps({'scope':'Read-only exact failed systems and passive PCG history; no physics, tolerance, cap, preconditioner, or PDE changes','cases':results},indent=2)+'\n')
(r/'manifest.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(s.rglob('*')) if p.is_file()},'binary_sha256':hashlib.sha256((r/'audit').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps(results,indent=2))
