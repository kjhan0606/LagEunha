import concurrent.futures,hashlib,json,os,statistics,subprocess,time
from pathlib import Path
import numpy as np
r=Path(__file__).parent;b=r.parent;s=r/'frozen_source'
base=['mpiicx','-O2','-qopenmp','-std=gnu11','-DXYZDBL','-DGOTPM','-Wall','-Wextra']
common=['-DGFS_NATIVE_KEP','-DGFS_NATIVE_KEP_FILTER','-DGFS_NATIVE_GLOBAL_VELOCITY','-DGFS_NATIVE_WALL_VELOCITY','-DGFS_NATIVE_SCALAR_VELOCITY','-DGFS_NATIVE_CENTROID_STRAIN']
geom=[str(s/p) for p in ['Exam/gfs_fv_geometry.c','Exam/gfs_fv_point.c','Voro/voro.c']]
commands={}
for name,flag in [('block_audit','-DGFS_NATIVE_BLOCK_JACOBI'),('ic0_audit','-DGFS_NATIVE_IC0')]:
 commands[name]=base+common+[flag,str(s/'Exam/HydroCore/kep_screened_matrix_audit.c')]+geom+['-lm','-o',str(r/name)]
commands['ic0_graph']=base+common+['-DGFS_NATIVE_IC0',str(s/'Exam/HydroCore/kep_ic0_graph_audit.c')]+geom+['-lm','-o',str(r/'ic0_graph')]
commands['native']=base+common+['-DGFS_NATIVE_IC0',str(s/'Exam/gfs_fv_native.c'),str(s/'Exam/HydroCore/fv_native_evolution.c')]+geom+['-lm','-o',str(r/'native')]
def build(item):
 name,cmd=item;(r/(name+'_command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (r/(name+'_build.log')).open('x') as out:
  start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=120)
 return name,{'exit_code':p.returncode,'seconds':time.monotonic()-start}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:builds=dict(pool.map(build,commands.items()))
(r/'builds.json').write_text(json.dumps(builds,indent=2)+'\n');print('builds',json.dumps(builds),flush=True)
if any(v['exit_code'] for v in builds.values()):raise SystemExit(1)
(r/'manifest.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(s.rglob('*')) if p.is_file()},'binary_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in commands}},indent=2)+'\n')
env=dict(os.environ,OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',TMPDIR=str(r))
with (r/'graph_stdout.json').open('x') as out,(r/'graph_stderr.log').open('x') as err:p=subprocess.run([str(r/'ic0_graph'),str(r/'graph')],stdout=out,stderr=err,env=env,timeout=60)
assert p.returncode==0 and json.loads((r/'graph_stdout.json').read_text())['pass']
cases={'D1_blast':b/'scalar_centroid_strong_launch_v1/gates/D1_blast_N200/failure_trial.fv','D1_collision':b/'scalar_centroid_strong_launch_v1/gates/D1_collision_N200/failure_trial.fv','D2_Gresho64':b/'kep_filter_gates_v2/D2_gresho_N64/final.fv','D3_Sod16':b/'fv_native_sod_large_v1/D3_sod_N16/final.fv'}
reports={name:{'block':[],'ic0':[]} for name in cases}
for round_index in range(3):
 for name,state in cases.items():
  small=name.startswith('D1_');threads=1 if small else 8;cpus='16' if small else '0-7'
  order=['block','ic0'] if round_index!=1 else ['ic0','block']
  for mode in order:
   prefix=r/(name+'_'+mode+'_r'+str(round_index));cmd=['taskset','-c',cpus,str(r/(mode+'_audit')),str(state),str(prefix),'100']
   env=dict(os.environ,OMP_NUM_THREADS=str(threads),OMP_DYNAMIC='FALSE',TMPDIR=str(r))
   with Path(str(prefix)+'.json').open('x') as out,Path(str(prefix)+'_stderr.log').open('x') as err:
    start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err,env=env,timeout=120)
   Path(str(prefix)+'_process.json').write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256(state.read_bytes()).hexdigest()},indent=2)+'\n')
   assert p.returncode==0,(name,mode,round_index)
   result=json.loads(Path(str(prefix)+'.json').read_text());cost=json.loads(Path(str(prefix)+'_benchmark.json').read_text())
   record={'operator':result,'benchmark':cost}
   if mode=='ic0':
    algebra=json.loads(Path(str(prefix)+'_algebra.json').read_text());assert algebra['pass']
    assert result['native_RHS_status']==0 and result['true_scaled_residual']<=1e-12 and result['PCG_iterations']<=64 and cost['failures']==0
    assert abs(result['kinetic_pair_defect'])<1e-10 and abs(result['entropy_balance_defect'])<1e-10
    record['algebra']=algebra
   reports[name][mode].append(record)
   print(name,mode,round_index,'iters',result['PCG_iterations'],'true',result['true_scaled_residual'],'mean_solve',cost['mean_solve_seconds_including_all_setup_apply_and_true_checks'],flush=True)
# One canonical cross-mode comparison and independent dense factor identity.
for name in cases:
 a=r/(name+'_block_r0');c=r/(name+'_ic0_r0')
 assert Path(str(a)+'_matrix.csv').read_bytes()==Path(str(c)+'_matrix.csv').read_bytes(),name+' A'
 rows_a=np.genfromtxt(str(a)+'_rows.csv',delimiter=',',names=True);rows_c=np.genfromtxt(str(c)+'_rows.csv',delimiter=',',names=True)
 for field in ['mu','diagonal','b','scale','volume','qx','qy','qz','qdotx','qdoty','qdotz']:assert np.array_equal(rows_a[field],rows_c[field]),(name,field)
 report={'same_A_b_scale_geometry_and_physical_qdot':True}
 if name.startswith('D1_'):
  n=len(rows_c);L=np.eye(n);A=np.diag(rows_c['diagonal']);edge=np.genfromtxt(str(c)+'_matrix.csv',delimiter=',',names=True)
  for e in edge:
   i,j=int(e['i']),int(e['j']);A[i,j]-=e['aij'];A[j,i]-=e['aij']
  factors=np.genfromtxt(str(c)+'_factor.csv',delimiter=',',names=True);pivots=np.genfromtxt(str(c)+'_pivots.csv',delimiter=',',names=True)
  for f in factors:L[int(f['i']),int(f['j'])]=f['Lij']
  M=(L*pivots['Di'][None,:])@L.T
  report['independent_dense_LDL_exact_chain_relative_error']=float(np.max(abs(M-A))/(1+np.max(abs(A))))
  assert report['independent_dense_LDL_exact_chain_relative_error']<1e-12
  reference=np.fromfile(b/'scalar_centroid_solver_diagnostics_v1'/(('blast' if name=='D1_blast' else 'collision')+'_reference.vector.bin'),dtype=np.float64)
  report['relative_returned_z_error_against_60digit_LDL']=float(np.max(abs(rows_c['z_candidate']-reference)/(1+abs(reference))))
  assert report['relative_returned_z_error_against_60digit_LDL']<1e-10
 block=statistics.median(x['benchmark']['mean_solve_seconds_including_all_setup_apply_and_true_checks'] for x in reports[name]['block'])
 ic0=statistics.median(x['benchmark']['mean_solve_seconds_including_all_setup_apply_and_true_checks'] for x in reports[name]['ic0'])
 rhs_block=statistics.median(x['benchmark']['mean_whole_RHS_seconds'] for x in reports[name]['block'])
 rhs_ic0=statistics.median(x['benchmark']['mean_whole_RHS_seconds'] for x in reports[name]['ic0'])
 report.update({'block_median_solve_seconds':block,'IC0_median_solve_seconds':ic0,'IC0_over_block_solve_time':ic0/block,'IC0_over_block_whole_RHS_time':rhs_ic0/rhs_block,'note':'1D baseline fails accuracy; cost is its failed64 work window, not an equal-accuracy speedup. Geometry excluded from RHS benchmark.'})
 if name.startswith('D1_'):assert ic0<block,(name,'cost gate')
 reports[name]['comparison']=report
(r/'assessment.json').write_text(json.dumps({'scope':'Same physics8, four frozen numerical systems; no new trajectory/GIZMO qualification','cases':reports,'graph_guard_pass':True,'all_numeric_and_cost_gates_pass':True},indent=2)+'\n')
print(json.dumps({'gate_pass':True,'comparison':{n:v['comparison'] for n,v in reports.items()}},indent=2),flush=True)
