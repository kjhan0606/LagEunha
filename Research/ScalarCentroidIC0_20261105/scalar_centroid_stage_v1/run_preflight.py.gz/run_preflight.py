from pathlib import Path
import concurrent.futures,csv,hashlib,json,os,subprocess,time
import numpy as np
r=Path(__file__).parent;s=r/'frozen_source';b=r.parent
base=['mpiicx','-O2','-qopenmp','-std=gnu11','-DXYZDBL','-DGOTPM','-Wall','-Wextra']
common=['-DGFS_NATIVE_KEP','-DGFS_NATIVE_KEP_FILTER','-DGFS_NATIVE_GLOBAL_VELOCITY','-DGFS_NATIVE_BLOCK_JACOBI','-DGFS_NATIVE_WALL_VELOCITY']
choices={'00':[], '10':['-DGFS_NATIVE_SCALAR_VELOCITY'], '01':['-DGFS_NATIVE_CENTROID_STRAIN'], '11':['-DGFS_NATIVE_SCALAR_VELOCITY','-DGFS_NATIVE_CENTROID_STRAIN']}
geom=[str(s/p) for p in ['Exam/gfs_fv_geometry.c','Exam/gfs_fv_point.c','Voro/voro.c']]
commands={}
for mode,flags in choices.items():
 name='frozen_'+mode
 commands[name]=base+common+flags+['-DGFS_KEP_STRESS_DIAGNOSTICS','-DGFS_AUDIT_SOURCE_VERSION=5',str(s/'Exam/HydroCore/kep_failure_audit.c')]+geom+['-lm','-o',str(r/name)]
for name,unit in [('wall_audit','kep_wall_field_audit.c'),('frame_audit','kep_velocity_frame_audit.c'),('stress_audit','kep_stress_switch_audit.c')]:
 commands[name]=base+common+choices['11']+['-DGFS_KEP_STRESS_DIAGNOSTICS',str(s/'Exam/HydroCore'/unit)]+geom+['-lm','-o',str(r/name)]
commands['native']=base+common+choices['11']+[str(s/'Exam/gfs_fv_native.c'),str(s/'Exam/HydroCore/fv_native_evolution.c')]+geom+['-lm','-o',str(r/'native')]
def build(item):
 name,cmd=item;(r/(name+'_command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (r/(name+'_build.log')).open('x') as out:
  start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=120)
 return name,{'exit_code':p.returncode,'seconds':time.monotonic()-start}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:builds=dict(pool.map(build,commands.items()))
(r/'builds.json').write_text(json.dumps(builds,indent=2)+'\n');print('builds',json.dumps(builds),flush=True)
if any(v['exit_code'] for v in builds.values()):raise SystemExit(1)
(r/'manifest.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(s.rglob('*')) if p.is_file()},'binary_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in commands}},indent=2)+'\n')
env=dict(os.environ,OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',TMPDIR=str(r))
def run(name,cmd):
 (r/(name+'_run_command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (r/(name+'_stdout.jsonl')).open('x') as out,(r/(name+'_stderr.log')).open('x') as err:
  start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err,env=env,timeout=120)
 record={'exit_code':p.returncode,'seconds':time.monotonic()-start}
 (r/(name+'_process.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,record,flush=True)
 return record
unit_cmds=[('wall',[str(r/'wall_audit'),'fixtures']),('frame',[str(r/'frame_audit')]),('stress',[str(r/'stress_audit'),'fixtures'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:units=dict(zip([n for n,c in unit_cmds],pool.map(lambda nc:run(*nc),unit_cmds)))
if any(v['exit_code'] for v in units.values()):raise SystemExit(2)
for name in units:
 records=[json.loads(x) for x in (r/(name+'_stdout.jsonl')).read_text().splitlines()]
 assert all(x['pass'] for x in records),name
trial=b/'wall_velocity_strong_launch_v1/gates/D1_blast_N200/failure_trial.fv'
records={}
for mode in choices:
 name='frozen_'+mode
 p=run(name,[str(r/name),str(trial),str(r/name)])
 if p['exit_code']:raise SystemExit(3)
 c=np.genfromtxt(r/(name+'_cells.csv'),delimiter=',',names=True)
 stress=np.genfromtxt(r/(name+'_stress.csv'),delimiter=',',names=True)
 edge=stress[(stress['i']==3)&(stress['j']==4)][0]
 records[mode]={'audit':json.loads((r/(name+'_stdout.jsonl')).read_text()),'scope':json.loads((r/(name+'_scope.json')).read_text()),'pair':{key:float(edge[key]) for key in stress.dtype.names},'selected_gap_rate':float(c['selected_qdot'][4]-c['selected_qdot'][3]),'pair_only_stress_dt_bound':float(.4*min(c['mass'][3],c['mass'][4])/edge['stress_damping_coefficient']) if edge['stress_damping_coefficient']>0 else None}
 assert records[mode]['scope']['conserved_states_and_birth_parameters_unchanged_during_operator_evaluation']
same_A={mode:(r/('frozen_'+mode+'_matrix.csv')).read_bytes()==(r/'frozen_00_matrix.csv').read_bytes() for mode in choices}
same_rhs_length=(r/'frozen_00_rhs.csv').read_bytes()==(r/'frozen_01_rhs.csv').read_bytes() and (r/'frozen_10_rhs.csv').read_bytes()==(r/'frozen_11_rhs.csv').read_bytes()
assert all(same_A.values()) and same_rhs_length
mean=records['00']['pair']['mean_delta']
assert abs(records['10']['selected_gap_rate']-mean)<1e-12 and abs(records['11']['selected_gap_rate']-mean)<1e-12
assert records['01']['selected_gap_rate']==records['00']['selected_gap_rate']
assert abs(records['10']['pair']['Pi_native']/records['00']['pair']['Pi_native']-1)<1e-12
assert abs(records['11']['pair']['Pi_native']/records['01']['pair']['Pi_native']-1)<1e-12
assert records['11']['pair']['Pi_native']<records['00']['pair']['Pi_native']/1e6
report={'scope':'Four frozen operators only; no trajectory and no conditioning cure claim','operators':records,'all_A_byte_identical':same_A,'length_does_not_change_weight_rhs':same_rhs_length,'pass':True}
(r/'frozen_controls.json').write_text(json.dumps(report,indent=2)+'\n')
(r/'preflight.json').write_text(json.dumps({'scope':'Native fixture and frozen-operator gates only','units':units,'frozen_2x2_pass':True,'pass':True},indent=2)+'\n')
print(json.dumps({'preflight_pass':True,'pair_gap_rates':{n:v['selected_gap_rate'] for n,v in records.items()},'pair_Pi':{n:v['pair']['Pi_native'] for n,v in records.items()},'all_A_identical':same_A},indent=2),flush=True)
