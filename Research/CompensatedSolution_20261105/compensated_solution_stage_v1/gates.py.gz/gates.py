from decimal import Decimal,localcontext
import hashlib,json,os,statistics,subprocess,time
from pathlib import Path
import numpy as np
r=Path(__file__).resolve().parent
b=r.parent
env=dict(os.environ,TMPDIR=str(r),OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',PYTHONDONTWRITEBYTECODE='1')
for name in ['wall','frame','stress']:
    with (r/(name+'_fixtures_stdout.jsonl')).open('x') as out,(r/(name+'_fixtures_stderr.log')).open('x') as err:
        p=subprocess.run([str(r/(name+'_audit'))]+([] if name=='frame' else ['fixtures']),stdout=out,stderr=err,env=env,timeout=60)
    assert p.returncode==0,name
    print(name,'pass',flush=True)
exact=json.loads((b/'ic0_late_blast_diagnostics_v1/reference_decimal.json').read_text())['x_decimal']
with localcontext() as ctx:
    ctx.prec=80
    high=np.array([float(x) for x in exact],dtype=np.float64)
    low=np.array([float(Decimal(x)-Decimal.from_float(h)) for x,h in zip(exact,high)],dtype=np.float64)
np.vstack([high,low]).tofile(r/'reference_hi_lo.vector.bin')
late=b/'ic0_strong_resume_v1/gates/D1_blast_N200/failure_trial.fv'
with (r/'precision_stdout.log').open('x') as out,(r/'precision_stderr.log').open('x') as err:
    p=subprocess.run([str(r/'precision_audit'),str(late),str(r/'late'),str(r/'reference_hi_lo.vector.bin')],stdout=out,stderr=err,env=env,timeout=60)
print('precision status',p.returncode,flush=True)
assert p.returncode==0
assert json.loads((r/'late_precision.json').read_text())['pass']
cases={'late_blast':late,
       'D1_blast':b/'scalar_centroid_strong_launch_v1/gates/D1_blast_N200/failure_trial.fv',
       'D1_collision':b/'scalar_centroid_strong_launch_v1/gates/D1_collision_N200/failure_trial.fv',
       'D2_Gresho64':b/'kep_filter_gates_v2/D2_gresho_N64/final.fv',
       'D3_Sod16':b/'fv_native_sod_large_v1/D3_sod_N16/final.fv'}
reports={n:{'double':[],'comp':[]} for n in cases}
for k in range(3):
    for name,state in cases.items():
        small=not name.startswith(('D2_','D3_'))
        cpus,threads=('16',1) if small else ('0-7',8)
        for mode in (['double','comp'] if k!=1 else ['comp','double']):
            prefix=r/(name+'_'+mode+'_r'+str(k))
            cmd=['taskset','-c',cpus,str(r/(mode+'_audit')),str(state),str(prefix),'100']
            runenv=dict(env,OMP_NUM_THREADS=str(threads))
            with Path(str(prefix)+'.json').open('x') as out,Path(str(prefix)+'_stderr.log').open('x') as err:
                start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err,env=runenv,timeout=120)
            Path(str(prefix)+'_process.json').write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'OMP_NUM_THREADS':threads,'source_sha256':hashlib.sha256(state.read_bytes()).hexdigest()},indent=2)+'\n')
            assert p.returncode==0,(name,mode,k)
            record={'operator':json.loads(Path(str(prefix)+'.json').read_text()),'benchmark':json.loads(Path(str(prefix)+'_benchmark.json').read_text())}
            if mode=='comp':
                assert record['operator']['native_RHS_status']==0
                assert record['operator']['true_scaled_residual']<=1e-12
                assert record['benchmark']['failures']==0
                assert abs(record['operator']['kinetic_pair_defect'])<1e-10
                assert abs(record['operator']['entropy_balance_defect'])<1e-10
            reports[name][mode].append(record)
            print(name,mode,k,'CG',record['operator']['PCG_iterations'],'true',record['operator']['true_scaled_residual'],flush=True)
for name in cases:
    x=r/(name+'_double_r0');y=r/(name+'_comp_r0')
    assert Path(str(x)+'_matrix.csv').read_bytes()==Path(str(y)+'_matrix.csv').read_bytes()
    a=np.genfromtxt(str(x)+'_rows.csv',delimiter=',',names=True);c=np.genfromtxt(str(y)+'_rows.csv',delimiter=',',names=True)
    for field in ['mu','diagonal','b','scale','volume','qx','qy','qz','qdotx','qdoty','qdotz']:
        assert np.array_equal(a[field],c[field]),(name,field)
    ratio={}
    for key in ['mean_solve_seconds_including_all_setup_apply_and_true_checks','mean_whole_RHS_seconds']:
        v={mode:statistics.median(q['benchmark'][key] for q in reports[name][mode]) for mode in ['double','comp']}
        ratio[key]={'median_seconds':v,'comp_over_double':v['comp']/v['double']}
    reports[name]['comparison']={'same_A_b_scale_geometry_qdot':True,'costs':ratio,
                                 'scope':'Geometry/I/O excluded; late-blast double64 fails, no equal-accuracy speedup or GIZMO inference.'}
    if name=='late_blast':
        assert reports[name]['double'][0]['operator']['PCG_iterations']==64
        assert reports[name]['double'][0]['operator']['native_RHS_status']!=0
        assert ratio['mean_solve_seconds_including_all_setup_apply_and_true_checks']['comp_over_double']<1
assessment={'scope':'Same physical8, IC0, cap64, native true tolerance1e-12; two-word solution only',
            'precision_controls_pass':True,'fixture_count':52,'five_frozen_numeric_and_late_cost_gates_pass':True,'cases':reports}
(r/'assessment.json').write_text(json.dumps(assessment,indent=2,allow_nan=False)+'\n')
print(json.dumps({'all_gates_pass':True,'comparisons':{n:v['comparison'] for n,v in reports.items()}},indent=2),flush=True)
