"""Original full-target strong refinement, same physical8 and compensated IC0."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import shutil
import sys

r=Path(__file__).resolve().parent
b=r.parent
stage=b/'compensated_solution_stage_v2'
assert json.loads((b/'compensated_blast_resume_v1/whole_physical_path.json').read_text())['endpoint_pass']
assert json.loads((b/'ic0_strong_resume_v1/whole_physical_path.json').read_text())['collision']['endpoint_pass']
for name in ['run_fv_native_suite.py','run_kep_filter_gates.py']:
    shutil.copy2(stage/'frozen_source/Exam/HydroCore'/name,r/name)
sys.path.insert(0,str(r))
from run_fv_native_suite import execute,save
cases=[('D1_blast_N400',1,400,'blast',.038),('D1_collision_N400',1,400,'collision',.035)]
save(r/'registration.json',{'scope':'N400 from birth required for refinement; N200 accepted histories retained, no N200 rerun',
                          'physical_version':8,'solution_precision':'two-word accumulated z only','PCG_cap':64,'true_tolerance':1e-12,
                          'binary_sha256':hashlib.sha256((stage/'native').read_bytes()).hexdigest(),'cases':cases,
                          'CPU_sets':[[0],[8]],'OMP_NUM_THREADS':1,'guard_multiplier':1})
gates=r/'gates'
gates.mkdir(exist_ok=False)
def run(item):
    index,case=item
    record=execute(gates,stage/'native',case,[8*index],{'OMP_NUM_THREADS':'1','GFS_TEST_GUARD_MULTIPLIER':'1'})
    record['kinetic_ledger']=json.loads((gates/case[0]/'kinetic_ledger.json').read_text())
    record['rounding_ledger']=json.loads((gates/case[0]/'solution_rounding_ledger.json').read_text())
    return record
with ThreadPoolExecutor(max_workers=2) as pool:
    records=list(pool.map(run,enumerate(cases)))
save(r/'assessment.json',{'scope':'Endpoint and ledgers; physical reference norms assessed separately','cases':records,
                        'all_original_endpoints_reached':all(x['endpoint_pass'] for x in records)})
print(json.dumps(records,indent=2),flush=True)
if not all(x['endpoint_pass'] for x in records):
    raise SystemExit(1)
