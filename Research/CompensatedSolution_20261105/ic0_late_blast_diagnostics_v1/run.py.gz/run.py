"""Read-only native/60-digit analysis of the exact late blast failure."""
import hashlib
import json
import os
from decimal import Decimal, localcontext
from pathlib import Path
import shutil
import subprocess

import numpy as np

r = Path(__file__).resolve().parent
b = r.parent
repo = b.parent / 'Git_publish_native20pi_contact_20261104_v1'
s = r / 'frozen_source'
s.mkdir(exist_ok=False)
prior = json.loads((b/'ic0_stage_v1/manifest.json').read_text())
for name in prior['source_sha256']:
    out = s/name
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo/name, out)
cmd = json.loads((b/'scalar_centroid_solver_diagnostics_v1/build_command.json').read_text())
cmd = [x.replace(str(b/'scalar_centroid_solver_diagnostics_v1/frozen_source'), str(s))
       .replace('-DGFS_NATIVE_BLOCK_JACOBI', '-DGFS_NATIVE_IC0') for x in cmd]
cmd[-1] = str(r/'audit')
(r/'build_command.json').write_text(json.dumps(cmd, indent=2)+'\n')
env = dict(os.environ, OMP_NUM_THREADS='1', OMP_DYNAMIC='FALSE', TMPDIR=str(r),
           PYTHONDONTWRITEBYTECODE='1')
with (r/'build.log').open('x') as out:
    p = subprocess.run(cmd, stdout=out, stderr=subprocess.STDOUT, env=env, timeout=120)
assert p.returncode == 0
source = b/'ic0_strong_resume_v1/gates/D1_blast_N200'
state = source/'failure_trial.fv'
source_sha = hashlib.sha256(state.read_bytes()).hexdigest()

def run(name, vector=None):
    command = [str(r/'audit'), str(state), str(r/name)]
    if vector is not None:
        command += ['--candidate-z', str(vector)]
    with (r/(name+'.json')).open('x') as out, (r/(name+'_stderr.log')).open('x') as err:
        p = subprocess.run(command, stdout=out, stderr=err, env=env, timeout=60)
    (r/(name+'_process.json')).write_text(json.dumps({'command':command, 'exit_code':p.returncode}, indent=2)+'\n')
    assert p.returncode == 0
    return json.loads((r/(name+'.json')).read_text())

native = run('blast')
original = json.loads((source/'failure_stage.json').read_text())
assert native['true_residual'] == original['true_scaled_residual']
assert native['actual_PCG_iterations'] == 64 and native['screened_solve_status'] != 0
cells = np.genfromtxt(r/'blast_cells.csv', delimiter=',', names=True)
edges = np.genfromtxt(r/'blast_matrix.csv', delimiter=',', names=True)
rhs = np.genfromtxt(r/'blast_rhs.csv', delimiter=',', names=True)
history = np.genfromtxt(r/'blast_pcg_history.csv', delimiter=',', names=True)
n = len(cells)
with localcontext() as ctx:
    ctx.prec = 60
    mu = [Decimal.from_float(float(x)) for x in cells['mu']]
    diag = mu.copy()
    off = [Decimal(0)]*(n-1)
    for edge in edges:
        i,j = int(edge['i']),int(edge['j'])
        assert j == i+1
        a = Decimal.from_float(float(edge['aij']))
        diag[i] += a
        diag[j] += a
        off[i] -= a
    D = [Decimal(0)]*n
    L = D.copy()
    y = D.copy()
    D[0] = diag[0]
    y[0] = Decimal.from_float(float(rhs['b'][0]))
    for i in range(1,n):
        L[i] = off[i-1]/D[i-1]
        D[i] = diag[i]-L[i]*off[i-1]
        assert D[i]>0
        y[i] = Decimal.from_float(float(rhs['b'][i]))-L[i]*y[i-1]
    exact = D.copy()
    exact[-1] = y[-1]/D[-1]
    for i in range(n-2,-1,-1):
        exact[i] = y[i]/D[i]-L[i+1]*exact[i+1]
    text = [str(x) for x in exact]
reference = np.array([float(x) for x in exact], dtype=np.float64)
reference.tofile(r/'reference.vector.bin')
(r/'reference_decimal.json').write_text(json.dumps({'scope':'Independent 60-digit frozen linear solve, no PDE', 'decimal_precision':60, 'x_decimal':text}, indent=2)+'\n')
run('reference', r/'reference.vector.bin')
check = json.loads((r/'reference_candidate_check.json').read_text())
rows = np.genfromtxt(r/'reference_candidate_rows.csv', delimiter=',', names=True)
worst = np.argsort(abs(rows['native_true_residual'])/rows['scale'])[-6:][::-1]
pair = native['closest_pair']
i,j = pair
edge = edges[(edges['i']==i)&(edges['j']==j)]
assert len(edge)==1
a = float(edge['aij'][0])
result = {'scope':'Exact failed IC0 state, passive history and independent frozen linear algebra only',
          'native_failure_reproduced_exactly':True, 'native_solver':native,
          'first_true_pass_iteration':next((int(x['iteration']) for x in history if x['true_scaled_flux_residual']<=1e-12),None),
          'minimum_true_scaled_residual_in_64':float(min(history['true_scaled_flux_residual'])),
          'independent_60digit_rounded_double':check,
          'worst_reference_rows':[{k:float(rows[k][int(i)]) for k in rows.dtype.names} for i in worst],
          'closest_pair':{'i':i,'j':j,'aij':a,'z_i':float(reference[i]),'z_j':float(reference[j]),
                          'z_difference':float(reference[j]-reference[i]),
                          'one_ulp_i_scaled_by_face_jacobian':float(abs(np.spacing(reference[i]))*a/rhs['scale'][i]),
                          'one_ulp_j_scaled_by_face_jacobian':float(abs(np.spacing(reference[j]))*a/rhs['scale'][j])},
          'input_trial_bytes_unchanged':hashlib.sha256(state.read_bytes()).hexdigest()==source_sha}
(r/'assessment.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
(r/'manifest.json').write_text(json.dumps({'source_sha256':{str(f.relative_to(s)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(s.rglob('*')) if f.is_file()},'binary_sha256':hashlib.sha256((r/'audit').read_bytes()).hexdigest(),'source_trial_sha256':source_sha}, indent=2)+'\n')
print(json.dumps(result, indent=2))
