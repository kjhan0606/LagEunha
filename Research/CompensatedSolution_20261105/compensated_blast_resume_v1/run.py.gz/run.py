"""Resume valid physical8 blast after all compensated-solution gates pass."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import numpy as np

r=Path(__file__).resolve().parent
b=r.parent
stage=b/'compensated_solution_stage_v2'
assert json.loads((stage/'assessment.json').read_text())['five_frozen_numeric_and_late_cost_gates_pass']
env=dict(os.environ,TMPDIR=str(r),OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',PYTHONDONTWRITEBYTECODE='1')
source=b/'ic0_strong_resume_v1/gates/D1_blast_N200'
state=source/'final.fv'
for mode in ['double','comp']:
    prefix=r/(mode+'_entry')
    cmd=[str(stage/(mode+'_audit')),str(state),str(prefix)]
    with Path(str(prefix)+'.json').open('x') as out,Path(str(prefix)+'_stderr.log').open('x') as err:
        p=subprocess.run(cmd,stdout=out,stderr=err,env=env,timeout=60)
    assert p.returncode==0
    assert json.loads(Path(str(prefix)+'.json').read_text())['native_RHS_status']==0
assert (r/'double_entry_matrix.csv').read_bytes()==(r/'comp_entry_matrix.csv').read_bytes()
a=np.genfromtxt(r/'double_entry_rows.csv',delimiter=',',names=True)
c=np.genfromtxt(r/'comp_entry_rows.csv',delimiter=',',names=True)
for field in ['mu','diagonal','b','scale','volume','qx','qy','qz','qdotx','qdoty','qdotz']:
    assert np.array_equal(a[field],c[field]),field
reject=r/'diagnostic_rejection'
reject.mkdir(exist_ok=False)
with (reject/'stdout.log').open('x') as out,(reject/'stderr.log').open('x') as err:
    code=subprocess.run([str(stage/'native'),'1','200','blast','.038','1',str(source/'failure_trial.fv')],cwd=reject,stdout=out,stderr=err,env=env,timeout=60).returncode
assert code==3 and not (reject/'initial.fv').exists()
for name in ['run_fv_native_suite.py','run_kep_filter_gates.py']:
    shutil.copy2(stage/'frozen_source/Exam/HydroCore'/name,r/name)
sys.path.insert(0,str(r))
from run_fv_native_suite import execute,save
save(r/'entry_checks.json',{'same_A_b_scale_geometry_qdot_across_precision':True,'physical_version':8,'diagnostic_restart_rejected':True,'parent_accepted_sha256':hashlib.sha256(state.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((stage/'native').read_bytes()).hexdigest()})
gates=r/'gates'
gates.mkdir(exist_ok=False)
record=execute(gates,stage/'native',('D1_blast_N200',1,200,'blast',.038),[0],{'OMP_NUM_THREADS':'1','GFS_TEST_GUARD_MULTIPLIER':'1'},state)
case=gates/'D1_blast_N200'
assert (case/'initial.fv').read_bytes()==state.read_bytes()
old=json.loads((b/'ic0_strong_resume_v1/whole_physical_path.json').read_text())['blast']
new=json.loads((case/'result.json').read_text())
kin=json.loads((case/'kinetic_ledger.json').read_text())
whole={'scope':'One physical8 trajectory, block-PCG then double IC0 then compensated-solution IC0; not one-backend speed benchmark',
       'parent_accepted_time':old['final_time'],'final_time':new['time'],'original_target':.038,
       'endpoint_pass':record['endpoint_pass'],'entry_checkpoint_byte_identical':True,'steps_total':new['steps'],
       'steps_in_latest_resume':new['new_steps'],
       'all_path_max_conservation_ledger':max(old['all_path_max_conservation_ledger'],new['maximum_ledger_error']),
       'all_path_max_residual_corrected_mass_weight_invariant':max(old['all_path_max_residual_corrected_mass_weight_invariant'],new['maximum_integrated_residual_invariant_error']),
       'whole_path_kinetic_RK_abs_defect':old['whole_path_kinetic_RK_abs_defect']+kin['kinetic_RK_defect_abs_sum'],
       'whole_path_integrated_stress_heat':old['whole_path_integrated_stress_heat']+kin['integrated_compression_thermal_production'],
       'whole_path_max_semidiscrete_entropy_balance_defect':max(old['whole_path_max_semidiscrete_entropy_balance_defect'],kin['maximum_semidiscrete_entropy_balance_defect']),
       'last_result':new,'rounding_ledger':json.loads((case/'solution_rounding_ledger.json').read_text())}
save(r/'whole_physical_path.json',whole)
print(json.dumps(whole,indent=2),flush=True)
if not record['endpoint_pass']:
    raise SystemExit(1)
