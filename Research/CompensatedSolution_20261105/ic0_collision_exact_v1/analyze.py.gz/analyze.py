"""Independent Athena exact Riemann comparison on actual native FV intervals."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

r = Path(__file__).resolve().parent
b = r.parent
source = b/'ic0_strong_resume_v1/gates/D1_collision_N200'
athena = b/'shu_independent_athena_v1/athena_source/tst/regression'
sys.dont_write_bytecode = True
sys.path.insert(0, str(athena))
from scripts.utils.RiemannSolver.riemann import riemann_problem

spec = json.loads((source/'problem_spec.json').read_text())
result = json.loads((source/'result.json').read_text())
assert not result['failed'] and result['time']==spec['original_endpoint']
gamma = spec['gamma']
t = result['time']
x0 = spec['cuts'][0]
sol = riemann_problem(dict(dl=spec['rho'][0],ul=spec['velocity'][0],pl=spec['pressure'][0],
                          dr=spec['rho'][1],ur=spec['velocity'][1],pr=spec['pressure'][1]),gamma)
assert [w['kind'] for w in sol.waves] == ['shock','contact','shock']
speeds = [float(w['speed'][0]) for w in sol.waves]
cuts = [x0+t*x for x in speeds]
domain = spec['physical_domain']
states = [[q.rho,q.u,q.p] for q in sol.states]

def shock_flux(state,speed):
    rho,u,p = state
    E = p/(gamma-1)+.5*rho*u*u
    return np.array([rho*(u-speed),rho*u*(u-speed)+p,(E+p)*u-speed*E])

jump_errors = []
for left_state,right_state,speed in [(states[0],states[1],speeds[0]),(states[2],states[3],speeds[2])]:
    f0,f1 = shock_flux(left_state,speed),shock_flux(right_state,speed)
    jump_errors.append(float(np.max(abs(f0-f1)/(1+abs(f0)+abs(f1)))))
assert max(jump_errors)<1e-12
assert states[1][1:]==states[2][1:]

def fields(state):
    rho,u,p = state
    return np.array([rho,rho*u,p/(gamma-1)+.5*rho*u*u,p,u])

data = np.loadtxt(source/'final.dat')
centers = data[:,1]+data[:,16]
left = centers-.5*data[:,10]
right = centers+.5*data[:,10]
order = np.argsort(left)
left,right,data = left[order],right[order],data[order]
assert np.min(right-left)>0
assert np.max(abs(right[:-1]-left[1:]))<1e-10
assert left[0]<domain[0] and right[-1]>domain[1]
absolute = np.zeros(5)
average_error = np.zeros(5)
reference_abs = np.zeros(5)
rows = []
measure = 0.
for row,l,h in zip(data,left,right):
    l,h = max(l,domain[0]),min(h,domain[1])
    if h<=l: continue
    width = h-l
    native = np.array([row[11],row[6]/row[10],row[9]/row[10],row[12],row[13]])
    segments = [l]+[x for x in cuts if l<x<h]+[h]
    integrals = np.zeros(5)
    for a,z in zip(segments[:-1],segments[1:]):
        k = int(np.searchsorted(cuts,.5*(a+z),side='right'))
        exact = fields(states[k])
        absolute += (z-a)*abs(native-exact)
        integrals += (z-a)*exact
        reference_abs += (z-a)*abs(exact)
    average = integrals/width
    average_error += width*abs(native-average)
    measure += width
    rows.append([int(row[0]),l,h,*native,*average])
assert abs(measure-(domain[1]-domain[0]))<1e-12
np.savetxt(r/'actual_interval_comparison.csv',rows,delimiter=',',
           header='id,left,right,rho_native,momentum_native,E_native,P_native,u_native,rho_exact_avg,momentum_exact_avg,E_exact_avg,P_exact_avg,u_exact_avg',comments='')
keys=['density','momentum_density','total_energy_density','pressure','velocity']
norms={key:{'piecewise_field_L1':float(absolute[i]/measure),
            'cell_average_L1':float(average_error[i]/measure),
            'relative_piecewise_field_L1':float(absolute[i]/reference_abs[i]),
            'reference_integral_absolute':float(reference_abs[i])} for i,key in enumerate(keys)}
checks={'scope':'Independent exact solution, no native PDE rerun; original physical interval [0,1]',
        'physical_version':8,'time':t,'gamma':gamma,'cut':x0,
        'wave_kinds':[w['kind'] for w in sol.waves],'wave_speeds':speeds,'wave_positions':cuts,
        'states_rho_u_P':states,'physical_interval_measure':measure,'native_final_cells':len(data),
        'physical_intersecting_cells':len(rows),'norms':norms,
        'independent_reference_Rankine_Hugoniot_max_relative_defect':max(jump_errors),
        'physical_cell_primitive_extrema':{key:{'minimum':float(min(row[3+k] for row in rows)),
                                               'maximum':float(max(row[3+k] for row in rows))}
                                            for key,k in [('density',0),('pressure',3),('velocity',4)]},
        'pressure_norm_convention':'Pressure from native cell conserved means, compared with exact primitive pressure; conservative energy and momentum norms reported separately.',
        'boundary_scope':'Existing guard multiplier1, no guard-doubling equivalence inferred.',
        'positive_final_state':bool(np.all(data[:,[5,10,11,12]]>0)),
        'floor_or_repair_count':result['floor_or_repair_count'],
        'reference_source':str(athena/'scripts/utils/RiemannSolver/riemann.py'),
        'sha256':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [source/'final.fv',source/'final.dat',source/'problem_spec.json',athena/'scripts/utils/RiemannSolver/riemann.py',athena/'scripts/utils/EquationOfState/eos.py']}}
(r/'assessment.json').write_text(json.dumps(checks,indent=2,allow_nan=False)+'\n')
plt.rcParams.update({'font.size':10,'axes.labelsize':10,'legend.fontsize':10})
fig,axes = plt.subplots(3,1,figsize=(6.2,7.2),sharex=True,gridspec_kw={'hspace':0})
xx = [domain[0],*cuts,domain[1]]
for ax,key,col,idx in zip(axes,['Density','Velocity','Pressure'],[11,13,12],[0,1,2]):
    for row,l,h in zip(data,left,right):
        if h<domain[0] or l>domain[1]: continue
        ax.plot([max(l,domain[0]),min(h,domain[1])],[row[col],row[col]],color='#2166ac',lw=1.1)
    ax.stairs([q[idx] for q in states],xx,color='black',lw=1.2,ls='--',baseline=None,label='Exact Riemann')
    ax.plot([],[],color='#2166ac',label='Native FV, N=200')
    ax.set_ylabel(key)
    ax.set_xlim(*domain)
    ax.margins(y=.18)
    ax.text(.02,.96,key,ha='left',va='top',transform=ax.transAxes)
axes[0].legend(loc='upper right',frameon=False)
axes[-1].set_xlabel('$x$')
fig.savefig(r/'collision_exact.png',dpi=170,bbox_inches='tight')
fig.savefig(r/'collision_exact.pdf',bbox_inches='tight')
plt.close(fig)
print(json.dumps({'wave_positions':cuts,'states_rho_u_P':states,'norms':norms},indent=2))
