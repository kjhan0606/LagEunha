"""Independent full-time blast references, native Athena++ evolution."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
from queue import Queue
import shutil
import subprocess
import time

import numpy as np

r=Path(__file__).resolve().parent
b=r.parent
old=b/'shu_independent_athena_v1/athena_source'
s=r/'athena_source'
s.mkdir(exist_ok=False)
for name in ['src','obj']:
    shutil.copytree(old/name,s/name)
(s/'bin').mkdir(exist_ok=False)
shutil.copy2(old/'Makefile',s/'Makefile')
(s/'Makefile').write_text((s/'Makefile').read_text().replace('PROBLEM_FILE = shu_osher.cpp','PROBLEM_FILE = lagforce_blast.cpp'))
shutil.copy2(r/'blast.cpp',s/'src/pgen/lagforce_blast.cpp')
env=dict(os.environ,TMPDIR=str(r),OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE')
cmd=['make','-j','4']
with (r/'build.log').open('x') as out:
    p=subprocess.run(cmd,cwd=s,stdout=out,stderr=subprocess.STDOUT,env=env,timeout=180)
assert p.returncode==0
registration={'scope':'Independent numerical Euler reference, not an exact solution or GIZMO timing',
              'upstream_commit':'37869da22cd357c2fbdd056fbb3781cdd4f430da',
              'source_parent':str(old),'build_scope':'Reuse matching existing Athena objects, compile new IC and relink; no clean-build claim',
              'Euler_method':'PPM xorder3, RK3, HLLC, CFL0.3',
              'domain':[0,1],'boundaries':['reflecting','reflecting'],'gamma':1.4,'target':.038,
              'density':[1,1,1],'velocity':[0,0,0],'pressure':[1000,.01,100],'cuts':[.1,.9],
              'initial_cell_pressure_integrated_exactly':True,'N':[1600,3200,6400],
              'EOS_floor_sites':'Existing eight abort-on-floor changes retained byte-for-byte',
              'binary_sha256':hashlib.sha256((s/'bin/athena').read_bytes()).hexdigest()}
assert (s/'src/eos/adiabatic_hydro.cpp').read_bytes()==(old/'src/eos/adiabatic_hydro.cpp').read_bytes()
(r/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
(r/'source_sha256.json').write_text(json.dumps({str(f.relative_to(s)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((s/'src').rglob('*')) if f.is_file()},indent=2)+'\n')
slots=Queue()
for cpu in [16,24]:slots.put(cpu)
def run(n):
    cpu=slots.get()
    try:
        case=r/('N'+str(n));case.mkdir(exist_ok=False)
        text=f'''<job>
problem_id = BlastReference
<output1>
file_type = tab
variable = prim
data_format = %24.16e
dt = .038
<output2>
file_type = hst
dt = .038
<time>
cfl_number = .3
nlim = -1
tlim = .038
integrator = rk3
xorder = 3
ncycle_out = 10000
<mesh>
nx1 = {n}
x1min = 0
x1max = 1
ix1_bc = reflecting
ox1_bc = reflecting
nx2 = 1
x2min = 0
x2max = 1
ix2_bc = periodic
ox2_bc = periodic
nx3 = 1
x3min = 0
x3max = 1
ix3_bc = periodic
ox3_bc = periodic
<hydro>
gamma = 1.4
'''
        (case/'athinput').write_text(text)
        cmd=['taskset','-c',str(cpu),str(s/'bin/athena'),'-i','athinput']
        with (case/'stdout.log').open('x') as out,(case/'stderr.log').open('x') as err:
            start=time.monotonic();p=subprocess.Popen(cmd,cwd=case,stdout=out,stderr=err,env=env)
            (case/'running.json').write_text(json.dumps({'pid':p.pid,'command':cmd})+'\n')
            status=p.wait()
        tables=sorted(case.glob('*.out1.*.tab'))
        record={'N':n,'exit_code':status,'wall_seconds':time.monotonic()-start,'tables':[str(x) for x in tables]}
        (case/'process.json').write_text(json.dumps(record,indent=2)+'\n')
        assert status==0 and len(tables)==2,(n,status)
        final=np.loadtxt(tables[-1]);assert np.isfinite(final).all() and np.min(final[:,[2,3]])>0
        assert 'time=3.800000' in tables[-1].read_text().splitlines()[0] or 'time=3.800000' in tables[-1].read_text().splitlines()[1]
        print(json.dumps(record),flush=True)
        return record
    finally:
        slots.put(cpu)
with ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,[1600,3200,6400]))
(r/'assessment.json').write_text(json.dumps({'scope':'Endpoint receipts only; reference self-convergence and native comparison pending','references':results},indent=2)+'\n')
