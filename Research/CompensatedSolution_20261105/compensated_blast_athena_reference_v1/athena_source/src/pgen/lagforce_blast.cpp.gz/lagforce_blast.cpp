// Independent Athena++ reference IC. Euler/PPM/RK3/HLLC solver unchanged.
#include <algorithm>
#include "../athena.hpp"
#include "../athena_arrays.hpp"
#include "../coordinates/coordinates.hpp"
#include "../eos/eos.hpp"
#include "../hydro/hydro.hpp"
#include "../mesh/mesh.hpp"
#include "../parameter_input.hpp"
void MeshBlock::ProblemGenerator(ParameterInput *pin) {
  (void)pin;
  const Real gm1=peos->GetGamma()-1.;
  for(int k=ks;k<=ke;k++)for(int j=js;j<=je;j++)for(int i=is;i<=ie;i++) {
    const Real l=pcoord->x1f(i),r=pcoord->x1f(i+1);
    const Real w0=std::max(Real(0),std::min(r,Real(.1))-l);
    const Real w1=std::max(Real(0),std::min(r,Real(.9))-std::max(l,Real(.1)));
    const Real w2=std::max(Real(0),r-std::max(l,Real(.9)));
    phydro->u(IDN,k,j,i)=1.;
    phydro->u(IM1,k,j,i)=phydro->u(IM2,k,j,i)=phydro->u(IM3,k,j,i)=0.;
    phydro->u(IEN,k,j,i)=(1000.*w0+.01*w1+100.*w2)/((r-l)*gm1);
  }
}
