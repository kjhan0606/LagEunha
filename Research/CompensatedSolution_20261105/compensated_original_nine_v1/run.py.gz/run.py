"""Complete remaining original physical8 1D endpoints, reuse strong histories."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
from queue import Queue
import shutil
import sys

r=Path(__file__).resolve().parent
b=r.parent
stage=b/'compensated_solution_stage_v2'
assert json.loads((b/'compensated_strong_N400_v1/assessment.json').read_text())['all_original_endpoints_reached']
for name in ['run_fv_native_suite.py','validate_fv_original_registry.py']:
    shutil.copy2(stage/'frozen_source/Exam/HydroCore'/name,r/name)
sys.path.insert(0,str(r))
from run_fv_native_suite import execute,save
from validate_fv_original_registry import contact_control,padding_comparison
specs=json.loads((b/'original_1d_registry_v1/original_specs.json').read_text())
cases=[('D1_'+p['problem']+'_N200',1,200,p['problem'],p['endpoint']) for p in specs if p['problem'] not in ('blast','collision')]
assert len(cases)==7
save(r/'registration.json',{'physical_version':8,'binary_sha256':hashlib.sha256((stage/'native').read_bytes()).hexdigest(),
                          'cases':cases,'all_original_endpoints':{p['problem']:p['endpoint'] for p in specs},
                          'reused_physical8_strong_paths':{'blast':str(b/'compensated_blast_resume_v1/whole_physical_path.json'),
                                                          'collision':str(b/'ic0_strong_resume_v1/whole_physical_path.json')},
                          'scope':'All original physical endpoints, not all-one-backend benchmark or all-reference accuracy pass',
                          'CPU_sets':[[0],[8]],'OMP_NUM_THREADS':1,'guard_multiplier':1})
gates=r/'gates'
gates.mkdir(exist_ok=False)
slots=Queue()
for cpu in [0,8]:slots.put(cpu)
def run(spec):
    cpu=slots.get()
    try:
        record=execute(gates,stage/'native',spec,[cpu],{'OMP_NUM_THREADS':'1','GFS_TEST_GUARD_MULTIPLIER':'1'})
        print(spec[3],record['exit_code'],record['endpoint_pass'],flush=True)
        return record
    finally:
        slots.put(cpu)
with ThreadPoolExecutor(max_workers=2) as pool:
    records=list(pool.map(run,cases))
assessment={'scope':'Same physical8, original full targets; individual physical reference and padding qualification separate',
            'new_cases':records,'all_new_endpoints_pass':all(x['endpoint_pass'] for x in records),
            'reused_blast_endpoint_pass':True,'reused_collision_endpoint_pass':True}
if assessment['all_new_endpoints_pass']:
    assessment['contact_exact_controls']=[contact_control(gates/('D1_'+p+'_N200'),p.startswith('moving')) for p in ['contact_open','moving_contact_open']]
save(r/'assessment.json',assessment)
print(json.dumps(assessment,indent=2),flush=True)
if not assessment['all_new_endpoints_pass']:
    raise SystemExit(1)
