from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
r=Path("/gpfs/kjhan/LagForce/UnifiedHydro_20261104_v1")
plt.rcParams.update({"font.size":11,"axes.labelsize":11,"legend.fontsize":11,"xtick.labelsize":10,"ytick.labelsize":10})
fig,ax=plt.subplots(1,2,figsize=(10.4,3.9));fig.subplots_adjust(left=.07,right=.98,bottom=.17,top=.98,wspace=.25)
radius=np.linspace(0,.7,701);speed=np.where(radius<=.2,5*radius,np.where(radius<=.4,2-5*radius,0))
ax[0].plot(radius,speed,color="black",lw=1.2,label="Analytic")
for side,color in [(64,"#0072B2"),(128,"#D55E00")]:
 case=r/"fv_native_smooth_v1"/f"D2_gresho_N{side}";f=np.loadtxt(case/"final.dat");v=np.loadtxt(case/"final_velocity.dat");dx=f[:,1]-.5;dy=f[:,2]-.5;rad=np.hypot(dx,dy);vp=(-dy*v[:,1]+dx*v[:,2])/rad
 edges=np.linspace(0,.7,57);index=np.digitize(rad,edges)-1;centers=[];means=[]
 for i in range(56):
  mask=index==i
  if mask.any():centers.append(np.average(rad[mask],weights=f[mask,10]));means.append(np.average(vp[mask],weights=f[mask,10]))
 ax[0].plot(centers,means,color=color,label=f"{side}²",lw=1.1)
ax[0].set(xlim=(0,.7),ylim=(-.04,1.12),xlabel="$r$",ylabel=r"$v_\phi$")
ax[0].text(.03,.96,"Gresho, $t=1$",transform=ax[0].transAxes,va="top");ax[0].legend(loc="upper right",frameon=False)
for path,label,color in [(r/"fv_native_smooth_v1/D2_cold_N128","Registered step","#0072B2"),(r/"fv_cold_time_controls_v1/N128_dt4","Step factor 1/4","#D55E00")]:
 f=np.loadtxt(path/"final.dat").reshape(128,128,-1);ax[1].plot(f[:,:,2].mean(1),f[:,:,12].mean(1)/1e-6,label=label,color=color,lw=1.1)
ax[1].axhline(1,color="black",lw=1,ls="--",label="Analytic")
ax[1].set(xlim=(0,1),ylim=(0,9.2),xlabel="$y$",ylabel=r"$P/P_0$")
ax[1].text(.03,.96,"Cold shear, $t=0.25$",transform=ax[1].transAxes,va="top");ax[1].legend(loc="upper right",frameon=False)
for a in ax:a.tick_params(direction="in",top=True,right=True)
fig.savefig(r/"fv_smooth_figures_v1/smooth_physics_gate.png",dpi=180)
fig.savefig(r/"fv_smooth_figures_v1/smooth_physics_gate.pdf")
