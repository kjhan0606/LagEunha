import concurrent.futures, hashlib, json, os, subprocess, time
from pathlib import Path
root=Path(__file__).parent
s=root/'frozen_source'
base=['mpiicx','-O2','-qopenmp','-std=gnu11','-DXYZDBL','-DGOTPM','-Wall','-Wextra']
physics=['-DGFS_NATIVE_KEP','-DGFS_NATIVE_KEP_FILTER','-DGFS_NATIVE_GLOBAL_VELOCITY']
geom=[str(s/'Exam/gfs_fv_geometry.c'),str(s/'Exam/gfs_fv_point.c'),str(s/'Voro/voro.c')]
native=[str(s/'Exam/gfs_fv_native.c'),str(s/'Exam/HydroCore/fv_native_evolution.c')]+geom
jobs={}
for name,flags in [('default_native',[]),('filtered_native',physics[:2]),('global_native',physics),('block_native',physics+['-DGFS_NATIVE_BLOCK_JACOBI'])]:
 jobs[name]=base+flags+native+['-lm','-o',str(root/name)]
for name,unit,flags in [('point_audit','power_point_audit.c',[]),('stress_audit','kep_stress_switch_audit.c',physics[:2]+['-DGFS_KEP_STRESS_DIAGNOSTICS']),('global_audit','kep_global_velocity_audit.c',physics),('failure_diagonal','kep_failure_audit.c',physics+['-DGFS_KEP_STRESS_DIAGNOSTICS']),('failure_block','kep_failure_audit.c',physics+['-DGFS_KEP_STRESS_DIAGNOSTICS','-DGFS_NATIVE_BLOCK_JACOBI'])]:
 jobs[name]=base+flags+[str(s/'Exam/HydroCore'/unit)]+geom+['-lm','-o',str(root/name)]
def build(item):
 name,cmd=item
 (root/(name+'_command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 start=time.monotonic()
 with (root/(name+'_build.log')).open('w') as out:
  p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=120)
 record={'exit_code':p.returncode,'seconds':time.monotonic()-start}
 (root/(name+'_build_process.json')).write_text(json.dumps(record,indent=2)+'\n')
 return name,record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 result=dict(pool.map(build,jobs.items()))
(root/'builds.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
if any(r['exit_code'] for r in result.values()):raise SystemExit(1)
manifest={'source_sha256':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(s.rglob('*')) if p.is_file()},'binary_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in jobs}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env=dict(os.environ,OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE')
trial=root.parent/'global_velocity_strong_gates_v1/D1_collision_N200/failure_trial.fv'
old=root.parent/'kep_filter_gates_v2/D1_blast_N200/final.fv'
tests=[('point_audit',[]),('stress_audit',['fixtures']),('global_audit',[str(old)]),('failure_diagonal',[str(trial),str(root/'diagonal')]),('failure_block',[str(trial),str(root/'block')])]
receipts={}
for name,args in tests:
 cmd=[str(root/name)]+args
 with (root/(name+'_stdout.jsonl')).open('w') as out,(root/(name+'_stderr.log')).open('w') as err:
  start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err,env=env,timeout=120)
 record={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'OMP_NUM_THREADS':1}
 (root/(name+'_process.json')).write_text(json.dumps(record,indent=2)+'\n')
 receipts[name]=record
 print(name,p.returncode,flush=True)
(root/'checks.json').write_text(json.dumps(receipts,indent=2)+'\n')
if any(r['exit_code'] for r in receipts.values()):raise SystemExit(2)
