#include <cuda_runtime.h>
#include <cstdio>
#include <cmath>
#include "../frozen_source/Exam/gfs_fv_ale.h"
template<int Mode> __host__ __device__ void eval(double out[10]){
  int dim=1; double n[3]={1,0,0};
  GfsFvPrimitive l={1,1,{-8,0,0}},r={.125,.1,{8,0,0}};
  GfsFvFan fan; double own[5]={0},dummy[5]={0};const double *q;
  if(Mode!=2){fan=gfs_fv_fan(dim,l,r,n,1.4);q=fan.state[0];}
  else{gfs_fv_state_flux(dim,l,n,1.4,own,dummy);q=own;}
  GfsFvSample sample={0};if(Mode==1||Mode==4)sample=gfs_fv_sample(&fan,-.6);
  double rate[5]={0};rate[2]=-q[2]-1;rate[1]=.2;
  double bound=0;if(Mode==2||Mode==3||Mode==4)bound=gfs_fv_admissible_interval(dim,q,rate);
  for(int c=0;c<5;c++)out[c]=q[c];
  out[5]=gfs_fv_internal(dim,q);out[6]=bound;
  out[7]=sample.flux[0];out[8]=sample.flux[1];out[9]=sample.flux[2];
}
template<int Mode> __global__ void kernel(double *out){eval<Mode>(out);}
template<int Mode> void run(double *d){
  double a[10],b[10];kernel<Mode><<<1,1>>>(d);cudaDeviceSynchronize();cudaMemcpy(a,d,sizeof(a),cudaMemcpyDeviceToHost);eval<Mode>(b);
  std::printf("Mode%d",Mode);for(int i=0;i<10;i++)std::printf(" c%d=%.17g/%.17g",i,a[i],b[i]);std::puts("");
}
int main(){double *d;cudaMalloc(&d,80);run<0>(d);run<1>(d);run<2>(d);run<3>(d);run<4>(d);cudaFree(d);return cudaGetLastError()!=cudaSuccess;}
