from pathlib import Path
import json,subprocess,time
r=Path(__file__).parent
cmd=['python3',str(r/'run_kep_filter_gates.py'),str(r/'gates'),str(r.parent/'wall_velocity_stage_v1/wall_native'),'--select','blast','collision','--core-version','5']
with (r/'stdout.log').open('x') as out,(r/'stderr.log').open('x') as err:
 start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err)
record={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start}
(r/'controller_process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
