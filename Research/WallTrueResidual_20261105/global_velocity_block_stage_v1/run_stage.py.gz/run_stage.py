from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time
root=Path(__file__).parent
base=root.parent
old=base/'push_review_20261105_v1'
commands={}
for name in ['global_native','block_native']:
 cmd=json.loads((old/(name+'_command.json')).read_text())
 cmd=[x.replace(str(old/'frozen_source'),str(root/'frozen_source')) for x in cmd]
 cmd[-1]=str(root/name)
 commands[name]=cmd
 for v in [0]:
  with (root/(name+'_build.log')).open('x') as out:
   start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=120)
  (root/(name+'_command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
  (root/(name+'_build_process.json')).write_text(json.dumps({'exit_code':p.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
  if p.returncode:raise SystemExit(p.returncode)
s=root/'frozen_source'
(root/'manifest.json').write_text(json.dumps({'source':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(s.rglob('*')) if p.is_file()},'binaries':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in commands}},indent=2)+'\n')
def replay():
 case=root/'diagonal_blast_one_step_replay';case.mkdir(exist_ok=False)
 checkpoint=base/'global_velocity_strong_gates_v1/D1_blast_N200/final.fv'
 cmd=[str(root/'global_native'),'1','200','blast','.038','1',str(checkpoint)]
 env=dict(os.environ,OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',TMPDIR=str(root),GFS_TEST_GUARD_MULTIPLIER='1')
 start=time.monotonic()
 with (case/'stdout.log').open('x') as out,(case/'stderr.log').open('x') as err:
  p=subprocess.run(['taskset','-c','16']+cmd,cwd=case,env=env,stdout=out,stderr=err)
 result=json.loads((case/'result.json').read_text())
 record={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'unchanged_accepted_checkpoint':checkpoint.read_bytes()==(case/'final.fv').read_bytes(),'new_steps':result['new_steps'],'time':result['time']}
 (case/'process.json').write_text(json.dumps(record,indent=2)+'\n')
 return record
def gates():
 cmd=['python3',str(root/'run_kep_filter_gates.py'),str(root/'birth_strong_gates'),str(root/'block_native'),'--select','blast','collision','--core-version','4']
 with (root/'controller_stdout.log').open('x') as out,(root/'controller_stderr.log').open('x') as err:
  start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err)
 record={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start}
 (root/'controller_process.json').write_text(json.dumps(record,indent=2)+'\n')
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 a=pool.submit(replay);b=pool.submit(gates)
 results={'diagonal_replay':a.result(),'birth_block_gates':b.result()}
(root/'stage_processes.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2),flush=True)
