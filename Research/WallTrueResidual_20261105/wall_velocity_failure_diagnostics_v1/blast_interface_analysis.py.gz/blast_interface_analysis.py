import csv,json
from pathlib import Path
import numpy as np
r=Path(__file__).parent
rows=list(csv.DictReader((r/'blast_rejected_cells.csv').open()))
geos=list(csv.DictReader((r/'blast_rejected.csv').open()))
i=3;j=4;a={k:float(v) for k,v in rows[i].items()};b={k:float(v) for k,v in rows[j].items()}
a['W']=float(geos[i]['W']);b['W']=float(geos[j]['W'])
ld=np.longdouble
face=(ld(a['q'])+ld(b['q']))/2+(ld(a['W'])-ld(b['W']))/(2*(ld(b['q'])-ld(a['q'])))
G1=(a['mean_v']-a['own_extrapolated_qdot'])/(a['centroid']-a['q'])
G2=(b['mean_v']-b['own_extrapolated_qdot'])/(b['centroid']-b['q'])
u1=ld(a['mean_v'])+ld(G1)*(face-ld(a['centroid']))
u2=ld(b['mean_v'])+ld(G2)*(face-ld(b['centroid']))
delta=b['mean_v']-a['mean_v'];rec=float(u2-u1);h=(a['V']+b['V'])/2;dq=b['q']-a['q'];dc=b['centroid']-a['centroid']
s=min(-delta,-rec) if delta<0 and rec<0 else 0
rho=(a['rho']+b['rho'])/2;c=(np.sqrt(1.4*a['P']/a['rho'])+np.sqrt(1.4*b['P']/b['rho']))/2;chi=max(a['chi'],b['chi'])
pi=lambda distance:float(chi*rho*(c*h/distance*s+2*(h/distance*s)**2))
report={'scope':'Read-only actual rejected blast pair, analytic reconstruction/stress diagnosis; alternative length is NOT evolved or selected','pair':[i,j],'generator_q':[a['q'],b['q']],'cell_centroids':[a['centroid'],b['centroid']],'generator_gap':dq,'centroid_normal_separation':dc,'centroid_to_generator_length_ratio':dc/dq,'face_position':float(face),'cell_mean_velocity_difference':delta,'limited_reconstructed_face_velocity_difference':rec,'normal_velocity_traces_at_shared_face':[float(u1),float(u2)],'selected_generator_velocity_difference':b['own_extrapolated_qdot']-a['own_extrapolated_qdot'],'chi':chi,'stress_from_current_generator_length':pi(dq),'stress_if_only_centroid_normal_length_is_substituted':pi(dc),'strain_length_code_location':'Exam/gfs_fv_native.c build_points: compression *= .5*(hi+hj)/f->distance; f->distance is generator separation','interpretation':'Current physical cell-mean jump and LSQ locations use centroids, while AV strain denominator uses generator distance. This distinction and the discontinuous physical field require separate evaluation.'}
means=[float(row['mean_v']) for row in rows]
report['neighbor_cell_mean_velocities_2_to_5']=means[2:6]
report['pair_mean_extrema']=['local_maximum' if means[i]>=max(means[i-1],means[i+1]) else 'none','local_minimum' if means[j]<=min(means[j-1],means[j+1]) else 'none']
assert report['pair_mean_extrema']==['local_maximum','local_minimum']
report['hypothetical_standard_monotone_scalar_limiting']='The current positive slopes at these local extrema would both be zero. This is a frozen algebraic prediction, not an evolved control or a selected new method.'
report['hypothetical_zero_slope_gap_rate']=means[j]-means[i]
report['current_velocity_limiter']='A vector-radius bound using the largest neighbor velocity difference; scalar min/max bounds currently apply only to density and pressure.'
(r/'blast_interface_and_stress_length.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
