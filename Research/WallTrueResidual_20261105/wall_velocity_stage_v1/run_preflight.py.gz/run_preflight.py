import concurrent.futures, hashlib, json, os, subprocess, time
from pathlib import Path
r=Path(__file__).parent;b=r.parent;s=r/'frozen_source';old=b/'push_review_20261105_v1/frozen_source'
base=['mpiicx','-O2','-qopenmp','-std=gnu11','-DXYZDBL','-DGOTPM','-Wall','-Wextra']
filt=['-DGFS_NATIVE_KEP','-DGFS_NATIVE_KEP_FILTER']
global_flags=filt+['-DGFS_NATIVE_GLOBAL_VELOCITY','-DGFS_NATIVE_BLOCK_JACOBI']
wall_flags=global_flags+['-DGFS_NATIVE_WALL_VELOCITY']
diag=['-DGFS_KEP_STRESS_DIAGNOSTICS']
def geometry(root):return [str(root/'Exam/gfs_fv_geometry.c'),str(root/'Exam/gfs_fv_point.c'),str(root/'Voro/voro.c')]
commands={
 'wall_native':base+wall_flags+[str(s/'Exam/gfs_fv_native.c'),str(s/'Exam/HydroCore/fv_native_evolution.c')]+geometry(s)+['-lm','-o',str(r/'wall_native')],
 'wall_audit':base+wall_flags+diag+[str(s/'Exam/HydroCore/kep_wall_field_audit.c')]+geometry(s)+['-lm','-o',str(r/'wall_audit')],
 'stop_global':base+global_flags+diag+[str(s/'Exam/HydroCore/kep_failure_audit.c')]+geometry(s)+['-lm','-o',str(r/'stop_global')],
 'stop_filter':base+filt+diag+[str(s/'Exam/HydroCore/kep_failure_audit.c')]+geometry(s)+['-lm','-o',str(r/'stop_filter')],
 'old_stop_filter':base+filt+diag+[str(old/'Exam/HydroCore/kep_failure_audit.c')]+geometry(old)+['-lm','-o',str(r/'old_stop_filter')],
}
def build(item):
 name,cmd=item;(r/(name+'_command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (r/(name+'_build.log')).open('x') as out:
  start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=120)
 return name,{'exit_code':p.returncode,'seconds':time.monotonic()-start}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:builds=dict(pool.map(build,commands.items()))
(r/'builds.json').write_text(json.dumps(builds,indent=2)+'\n');print('builds',json.dumps(builds),flush=True)
if any(x['exit_code'] for x in builds.values()):raise SystemExit(1)
(r/'manifest.json').write_text(json.dumps({'source_sha256':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(s.rglob('*')) if p.is_file()},'binaries_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in commands}},indent=2)+'\n')
env=dict(os.environ,OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',TMPDIR=str(r))
def run(name,binary,args):
 cmd=[str(r/binary)]+list(map(str,args))
 with (r/(name+'_stdout.jsonl')).open('x') as out,(r/(name+'_stderr.log')).open('x') as err:
  start=time.monotonic();p=subprocess.run(cmd,stdout=out,stderr=err,env=env,timeout=120)
 record={'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start}
 (r/(name+'_process.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(name,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(name)
 return [json.loads(line) for line in (r/(name+'_stdout.jsonl')).read_text().splitlines()]
checks={}
checks['wall_fixtures']=run('wall_fixtures','wall_audit',['fixtures'])
assert all(x['pass'] for x in checks['wall_fixtures'])
checks['readonly_old_blast']=run('readonly_old_blast','wall_audit',[b/'global_velocity_strong_gates_v1/D1_blast_N200/final.fv'])
assert all(x['pass'] for x in checks['readonly_old_blast'])
checks['collision_stop']=run('collision_stop','stop_global',[b/'global_velocity_block_stage_v1/birth_strong_gates/D1_collision_N200/failure_trial.fv',r/'collision_stop'])
stop=json.loads((r/'collision_stop_termination.json').read_text())
assert stop['status']==0 and stop['stop_reason']==2 and stop['reported_residual_matches_returned_z'] and stop['nonfinite_true_residual_rejected']
checks['early_blast']=run('early_blast','stop_filter',[b/'kep_filter_gates_v1/D1_blast_N200/final.fv',r/'early_blast','--euler-trial','3.5851060854353769e-05'])
checks['early_blast_old']=run('early_blast_old','old_stop_filter',[r/'early_blast_derived_trial.fv',r/'early_blast_old'])
early=json.loads((r/'early_blast_termination.json').read_text())
assert early['status']==0 and early['first_recursive_candidate_true_residual']>1e-12 and early['reliable_true_residual_replacements']>=1 and early['true_residual_of_returned_z']<=1e-12 and early['reported_residual_matches_returned_z']
same_early={suffix:(r/('early_blast_'+suffix)).read_bytes()==(r/('early_blast_old_'+suffix)).read_bytes() for suffix in ['matrix.csv','rhs.csv','cells.csv']}
same_collision={suffix:(r/('collision_stop_'+suffix)).read_bytes()==(b/'global_velocity_block_diagnostics_v1'/('block_collision_matrix_'+suffix)).read_bytes() for suffix in ['matrix.csv','rhs.csv','cells.csv']}
assert all(same_early.values()) and all(same_collision.values())
report={'scope':'Native numerical and boundary-operator preflight only, no completed PDE','checks':checks,'early_blast_termination':early,'collision_termination':stop,'early_same_A_b_scale_cells':same_early,'collision_same_A_b_scale_cells':same_collision,'pass':True}
(r/'preflight.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'pass':True,'wall_fixtures':len(checks['wall_fixtures']),'early_blast_termination':early,'collision_termination':stop},indent=2),flush=True)
