        parameter (n=64,nmax=32,nn=16,n1=64,n2=32,n3=16,n4=32)
